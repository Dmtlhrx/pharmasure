// tailwind.config.js
module.exports = {
  content: [
    './src/**/*.{html,js,jsx,ts,tsx}',  // Assurez-vous que tous les fichiers .js, .jsx, .ts, .tsx sont scannés
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
